# Intro

In diesem Jupyter Book wird das Paper "Segment Anything", welches 2023 von Meta herausgebracht wurde, vorgestellt. <br>
Hier soll eine Übersicht über das Thema "Semantic Segmentation" gegeben werden, indem zuerst allgemein das Thema vorgestellt wird und danach auf die einzelnen Aspekte des Papers eingegangen wird. <br>

Dieses Jupyter Book ist im Rahmen der Vorlesung "Object Recognition in Image and Video Data" im Sommersemester 2023 entstanden und wurde von Patrick Singer und Teresa Mary Kutzner erstellt.

### Inhaltsverzeichnis:

```{tableofcontents}
```
